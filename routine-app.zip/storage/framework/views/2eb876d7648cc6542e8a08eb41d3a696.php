<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Sign in</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo e(URL::asset('assets/css/auth.css')); ?>" rel="stylesheet">
</head>

<body>

    <div class="auth-wrapper">
        <div class="auth-card shadow">

            <h3 class="text-center mb-2">Welcome 👋</h3>
            <p class="text-center text-muted mb-4">
                Sign in or create an account using Google
            </p>

            <!-- Google Login -->
            <a href="" class="btn btn-google w-100">
                <img src="https://developers.google.com/identity/images/g-logo.png" alt="Google">
                Continue with Google
            </a>

            <p class="text-center text-muted small mt-4">
                By continuing, you agree to our Terms & Privacy Policy
            </p>
        </div>
    </div>

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\routine-app\resources\views/auth.blade.php ENDPATH**/ ?>