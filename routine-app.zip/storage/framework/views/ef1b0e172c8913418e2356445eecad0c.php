<?php $__env->startSection('title'); ?>
    Routine App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(URL::asset('assets/css/auth.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="auth-card card-box shadow">
        <h3 class="text-center mb-2">Welcome 👋</h3>
        <p class="text-center text-muted mb-4">
            Sign in or create an account using Google
        </p>

        <!-- Google Login -->
        <a href="<?php echo e(route('google.login')); ?>" class="btn btn-google w-100">
            <img src="https://developers.google.com/identity/images/g-logo.png" alt="Google">
            Continue with Google
        </a>

        <p class="text-center text-muted small mt-4">
            By continuing, you agree to our Terms & Privacy Policy
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\routine-app\resources\views/web/auth.blade.php ENDPATH**/ ?>