<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Daily Todo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo e(URL::asset('assets/css/todo.css')); ?>" rel="stylesheet">
</head>

<body>

    <div class="container py-5">
        <div class="todo-card shadow">

            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4>🗓 Daily Tasks</h4>

                <!-- Date Picker -->
                <input type="date" id="taskDate" class="form-control w-auto"
                    value="<?php echo e(request('date', now()->toDateString())); ?>">
            </div>

            <!-- Add Task Form -->
            <form method="POST" action="<?php echo e(route('tasks.store')); ?>" class="mb-3">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="date" id="formDate">

                <div class="input-group">
                    <input type="text" name="title" class="form-control" placeholder="New task..." required>
                    <button class="btn btn-primary">
                        <i class="bi bi-plus-lg"></i>
                    </button>
                </div>
            </form>

            <!-- Tasks List -->
            <ul class="list-group" id="todoList">

                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item todo-item" data-id="<?php echo e($task->id); ?>">

                        <div class="d-flex justify-content-between align-items-center">

                            <div class="form-check">
                                <input class="form-check-input toggle-done" type="checkbox"
                                    data-id="<?php echo e($task->id); ?>" <?php echo e($task->is_done ? 'checked' : ''); ?>>

                                <span class="<?php echo e($task->is_done ? 'done' : ''); ?>">
                                    <?php echo e($task->title); ?>

                                </span>
                            </div>

                            <i class="bi bi-grip-vertical drag-handle"></i>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js"></script>

    <script>
        window.csrfToken = "<?php echo e(csrf_token()); ?>";
    </script>

    <script src="<?php echo e(URL::asset('assets/js/todo.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\routine-app\resources\views/index.blade.php ENDPATH**/ ?>